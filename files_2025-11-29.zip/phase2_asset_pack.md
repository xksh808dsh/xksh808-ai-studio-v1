
# Phase 2: 4-Pulse Asset Pack for “30-min Tech Health Check”

## 1. Scroll-Stopping Opening Lines (≤ 7 words each)
1. “Your laptop is slower than you.”
2. “One click could save you $500.”
3. “Tech pain gone in 30 minutes.”

---

## 2. 20-Second Vertical Video Scripts (1080×1920)

### A. Problem Agitation
**Hook (0-3 s):**  
Text on screen: “Spinning wheel of death again?”  
You: “Staring at this instead of Netflix?”

**Agitate (3-10 s):**  
“Every freeze costs you 10 min of life. Add it up— that’s a vacation day per month.”

**Solution tease (10-18 s):**  
“I fix this in 30 min flat. $100. No data loss. No geek-speak.”

**CTA (18-20 s):**  
“Comment ‘FIX’—I’ll DM you a slot today.”

---

### B. Quick-Win Tip
**Hook (0-3 s):**  
Text: “Speed up Mac in 7 sec.”  
You hold stopwatch.

**Tip (3-12 s):**  
“Apple logo > System Settings > General > Login Items. Toggle OFF anything you don’t need at boot. Boom—free RAM.”

**Proof (12-17 s):**  
Screen record: boot time drops 18 → 9 sec.

**CTA (17-20 s):**  
“Want me to do 10 more hacks in person? Book below.”

---

### C. Social-Proof Testimonial
**Hook (0-3 s):**  
Text: “Real client, 2 hours ago.”

**Clip (3-15 s):**  
Vertical selfie of client:  
“Hey TikTok—just had my 30-min Tech Health Check. Laptop went from jet-engine noise to whisper quiet. Worth every penny of the hundred bucks.”

**CTA (15-20 s):**  
“Slots open tomorrow—comment ‘HEALTH’ to grab yours.”

---

## 3. 1080×1920 Thumbnail Template
- **Background:** Neon-gradient circuit board (left) → clean white (right) for contrast  
- **Left big text (oversized, 260 pt):** “SLOW PC?”  
- **Right sub-text (90 pt):** “Fixed in 30 min”  
- **Accent:** Cyan pulse ring around “30” to animate (1 s loop)  
- **Brand bar bottom (40 pt):** “@YourLocalTechPro”  
- **Safe zone:** Keep text within central 70 % for TikTok preview  

---

## 4. Google Business Profile Post Template
**Headline (max 58 char):**  
“30-Minute Tech Health Check—$100 Flat”

**Offer body (2 lines, 160 char max):**  
Line 1: “We kill pop-ups, boost speed, secure data—same day.”  
Line 2: “Book now, pay after service. Call or tap.”

**Call-now button:**  
Label: “Call Now” → link to tel:+1-XXX-XXX-XXXX

---

## 5. DM Script (TikTok → Calendly)
1. Thanks: “Hey [Name]—thanks for commenting ‘FIX’!”  
2. Qualify: “Quick Q: is your computer 3+ years old or just feels sluggish?”  
3. Value: “I free up 20 min avg boot time and secure any weak passwords—30 min, $100.”  
4. Close: “If that sounds good, grab a slot here: [Calendly link]—next openings tomorrow 2-6 pm.”  
5. Sign-off: “Talk soon, -[Your Name] @YourLocalTechPro”

---
