
# Phase 4: Capture & Segment Viewers  
**Goal:** Pixel-triggered lead capture → 3-tier audience export → Google-Sheet CRM

---

## 1. Pixel Setup (TikTok + GBP)
### 1.1 TikTok Pixel (3 s, 10 s, profile-click)
1. Events Manager → Pixel → Create  
   - Name: `LocalTechCheck`  
   - Type: `Manual install`  
2. Paste in `<head>` of Linktree/landing page:
```html
<script>
!function (w, d, t) {
  var s = d.createElement(t), f = d.getElementsByTagName(t)[0];
  s.src="https://analytics.tiktok.com/i18n/pixel/sdk.js"; f.parentNode.insertBefore(s,f);
}(window, document, 'script');
ttq.load('YOUR_PIXEL_ID');
ttq.page();
</script>
```
3. Add custom events:
```html
<script>
// 3-second watch
setTimeout(()=>ttq.track('Watch3s'), 3000);
// 10-second watch
setTimeout(()=>ttq.track('Watch10s'), 10000);
// profile click
function onProfileClick(){ttq.track('ProfileClick');}
</script>
```
4. Attach `onProfileClick()` to bio link & any “link-in-bio” buttons.

### 1.2 Google Business Profile (UTM + Click-ID)
- Append every bio link:  
  `https://yourlink.com/?utm_source=gbp&utm_medium=button&gbp_clickid={gclid}`
- Enable GBP “Performance” → “Calls & Clicks” export (daily CSV).

---

## 2. Daily Audience Export (3 Tiers)
| Tier | Trigger | Export Method | File Name |
|------|---------|---------------|-----------|
| T1   | Watch3s | TikTok Audiences → Export CSV | `watch3s_YYYY-MM-DD.csv` |
| T2   | Watch10s | same | `watch10s_YYYY-MM-DD.csv` |
| T3   | ProfileClick | same | `profileclick_YYYY-MM-DD.csv` |

**Automation (free):**  
1. Zapier Schedule (daily 06:00) → TikTok Lead-Gen → Google Drive folder `/tiktok_audiences/`  
2. Format: CSV with columns `user_id,event_time,country,device`

---

## 3. Google-Sheet CRM
Sheet name: `LocalTechLeads`  
Tabs: `Raw`, `Segmented`, `Hot`

### 3.1 Raw tab (auto-append)
Columns:  
`timestamp | platform | event | user_id | country | device | engagement_level`

### 3.2 Segmented tab (formula)
- `engagement_level` =  
  `IF(event="ProfileClick","HOT",IF(event="Watch10s","WARM","COLD"))`

### 3.3 Hot tab (filter view)
- `=FILTER(Segmented!A:H, Segmented!H="HOT")`

### 3.4 Auto-ingest via Zapier
Trigger: New CSV in Drive `/tiktok_audiences/` → Action: “Append Row” to Raw tab.

---

## 4. Stack & Cost
| Tool | Free Tier | Paid |
|------|-----------|------|
| TikTok Pixel | unlimited events | – |
| Zapier | 100 tasks/mo | $19.99/mo |
| Google Sheets | free | – |
| Google Drive | 15 GB | – |

---

## 5. SOP Checklist (daily)
- [ ] 06:00 Zapier pulls yesterday’s 3 CSVs  
- [ ] 06:05 Sheets formulas auto-segment  
- [ ] 08:00 Manually scan “Hot” tab → start DM outreach (Phase-2 script)  
- [ ] 09:00 Archive CSVs to `/archive/` folder

**Result:** Every viewer tagged COLD/WARM/HOT inside a single Google Sheet ready for retargeting & manual DM sales.
