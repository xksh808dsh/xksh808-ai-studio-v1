
# Phase 5: Deploy Remarketing Sequences

## 1. 15-Second CTA Video Script
**Format:** 9:16 vertical, upbeat music, bold captions  
**Script (≤15 s):**  
[0-2 s] Hook text: “Still waiting on that tech fix?”  
[2-6 s] Quick recap: “30-min Tech Health Check finds the 3 silent issues slowing your laptop.”  
[6-10 s] Scarcity: “Only 5 slots left this week.”  
[10-15 s] CTA + visual: “Tap below—book now, get $20 off.” (on-screen button pulse)

**Production notes:**  
- Film on phone in 4K, 60 fps  
- Caption font: Montserrat Bold, #00FF88 highlight  
- End-frame: Calendly QR code + profile handle

---

## 2. TikTok Auto-DM Logic (Zapier)
**Trigger:** New TikTok lead (CSV export daily 07:00)

### A. 3-second viewers (COLD)
**Condition:** watch_time ≥ 3 s AND < 10 s  
**Action:** Send DM  
**Message:**  
“Hi [first-name]! 👋 Saw you peeked at our Tech Health Check. What’s the #1 thing bugging your device right now? Reply & I’ll shoot you our free 5-step checklist.”  
*(No link yet—wait for reply to stay compliant)*

### B. 10-second viewers (WARM)
**Condition:** watch_time ≥ 10 s  
**Action:** Send DM  
**Message:**  
“Hey [first-name], looks like you’re serious about speed. Grab one of the last 5 slots this week—book here: [Calendly] and use code SAVE20 for $20 off. Expires Sunday.”

---

## 3. GBP “Call Now” Auto-Reply
**Tool:** Google Business Messages API → Zapier SMS  
**Trigger:** GBP “Call Now” button click  
**Auto-text (sent within 30 s):**  
“Thanks for calling! If you’d rather skip phone tag, what’s the best time for a 30-min Tech Health Check? Reply with a time and I’ll send a booking link.”  
**Follow-up (if they reply):**  
“Perfect—here’s your private booking link: [Calendly]. Looking forward to speeding up your tech!”

---

## 4. Implementation Checklist
- [ ] Upload 15-s CTA video to TikTok scheduler (post at 19:30 local)  
- [ ] Connect TikTok Lead Gen → Zapier → Google Sheet (audience list)  
- [ ] Create two Zaps (3-s vs 10-s filters) with DM actions  
- [ ] Generate Calendly coupon code SAVE20 (single-use per customer)  
- [ ] Enable GBP Messaging & link to Twilio/Zapier SMS webhook  
- [ ] Test each flow with dummy lead; verify SMS delivery & DM timing  
- [ ] Monitor reply rates daily; rotate coupon code weekly to maintain scarcity
