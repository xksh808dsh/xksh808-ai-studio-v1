## TODO List
- [x] Phase 1: Define Core Offer & Audience: Phase 1: Define Core Offer & Audience
- Identify the single service to sell (assume local “30-min Tech Health Check” at $100)
- Draft 7-word hook headline that promises a clear benefit
- List 3 pain points the service removes and 3 outcomes it delivers
- Select one primary short-form platform (assume TikTok) and one local discovery channel (assume Google Business Profile)


- [x] Phase 2: Build the 4-Pulse Asset Pack: Phase 2: Build the 4-Pulse Asset Pack
- Write 3 scroll-stopping opening lines (≤ 7 words each)
- Script three 20-second vertical videos: problem agitation, quick win tip, social-proof testimonial
- Design a 1080×1920 thumbnail template with bold text overlay
- Create a GBP post template: headline, 2-line offer, call-now button
- Draft DM script that thanks viewer, asks qualifying question, and drops Calendly link


- [x] Phase 3: Automate Publishing & Targeting: Phase 3: Automate Publishing & Targeting
- Compile 9 local hashtags and 3 trending sounds updated daily via RSS
- Schedule the 3 videos to auto-post at 08:00, 13:00, 19:00 local time
- Push the same content as GBP “Update” with geotagged photo
- Enable auto-first-comment with link to booking page


- [x] Phase 4: Capture & Segment Viewers: Phase 4: Capture & Segment Viewers
- Enable pixel on profile that fires at 3-second, 10-second, and profile-click events
- Export viewer lists into 3 custom audiences daily
- Store leads in a single Google Sheet with timestamp and engagement level


- [x] Phase 5: Deploy Remarketing Sequences: Phase 5: Deploy Remarketing Sequences
- Generate 15-second CTA video: recap value + limited slots this week
- Auto-DM 3-second viewers with soft question and link to free checklist
- Auto-DM 10-second viewers with direct Calendly invite and coupon code
- Auto-reply to GBP “Call Now” clicks with text asking preferred time and sending booking link


- [x] Phase 6: Daily Optimization & Reporting: Phase 6: Daily Optimization & Reporting
- Pull previous day metrics: impressions, 3-s views, 10-s views, profile clicks, bookings
- Identify best-performing hook line and duplicate it into two new variants
- Pause lowest-retention video and replace with fresh variant
- Update GBP description with new keyword if ranking outside top-5 map results


- [x] Phase 7: Package the System for Hand-off: Phase 7: Package the System for Hand-off
- Consolidate all templates, scripts, and schedules into one Markdown playbook
- Export pixel IDs, sheet URL, and posting calendar into a single config file
- Deliver the playbook and config file to the user
