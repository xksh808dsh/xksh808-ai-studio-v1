
# Phase 1: Core Offer & Audience Definition

## 1. Single Service to Sell
**Service Name:** 30-min Tech Health Check  
**Price:** $100 (one-time, local on-site or remote)  

## 2. 7-Word Hook Headline
“Fix Slow Devices & Save Hours—$100 Tech Check”

## 3. Pain Points Removed
1. Frustratingly slow computer or phone performance  
2. Constant pop-ups, viruses, or security warnings  
3. Fear of losing photos, files, or work data  

## 4. Outcomes Delivered
1. Lightning-fast device startup & app launch  
2. Bullet-proof security & automatic backup setup  
3. Peace of mind with a 30-day performance guarantee  

## 5. Primary Short-Form Platform
**TikTok** – 15-60 s tips, before/after screen recordings, local hashtags (#YourCityTechHelp)

## 6. Local Discovery Channel
**Google Business Profile** – 5-star reviews, “Book Now” button, weekly photo updates of happy clients
