
# 6-Phase Local-TikTok Lead Funnel – Complete Hand-off Playbook  
*(Everything you need to deploy in under 60 min)*

---

## 1. CORE OFFER & AUDIENCE
**Service:** 30-min Tech Health Check – $100 on-site or remote  
**7-Word Hook:** “Fix slow devices in 30 minutes”  
**Pain Points Removed:**  
1. Frustrating lag & crashes  
2. Fear of data loss / viruses  
3. Expensive big-box repair upsells  

**Outcomes Delivered:**  
1. 30 % speed boost guaranteed  
2. Same-day security scan & cleanup  
3. Flat-rate price, no upsell surprises  

**Primary Platform:** TikTok (short-form)  
**Local Discovery:** Google Business Profile (GBP)

---

## 2. 4-PULSE ASSET PACK
### A. Scroll-Stopping Openers (use as first 0-1 s text)
1. “Your iPhone is slower than you think”  
2. “Stop paying for storage you don’t need”  
3. “3 clicks to double your laptop speed”  

### B. 20-Second Vertical Video Scripts (≈ 45 words each)
1. **Problem Agitation**  
   [Visual: frozen screen] “Watching this wheel spin? That 3-year-old laptop is costing you 2 hrs a day. In 30 min I replace the bottleneck—no new computer needed. Book below.”  

2. **Quick-Win Tip**  
   [Visual: screen record] “Settings → General → iPhone Storage → Offload Unused Apps. One tap freed 8 GB for my client yesterday. Want me to do the rest? Link in bio.”  

3. **Social-Proof Testimonial**  
   [Visual: before/after Geekbench score] “Maria’s MacBook went from 4-min boot to 28 seconds. She paid one hundred flat. Comment ‘SPEED’ and I’ll do yours this week.”  

### C. Thumbnail Template (1080×1920)
- Bold 500 pt white text, center-aligned, 3-word max  
- Background: high-contrast device close-up, vignette -20 %  
- Add small red circle arrow pointing to issue  

### D. GBP Post Template
**Headline (35 char):** “Same-Day Tech Tune-Up $100”  
**Body (2 lines):** “Slow phone or laptop? 30-min fix at your home or office. Call now.”  
**Button:** “Call Now” (link to tracked number)

### E. DM-to-Calendly Script
“Hey [name]! 👋 Thanks for the ❤️ on my video. Quick Q: what device is bugging you most right now? Reply and I’ll send a free checklist + my next open slot.”  
*(after reply)* “Here’s the checklist + my calendar: calendly.com/30minTechCheck”

---

## 3. AUTOMATION & TARGETING
### Daily Hashtags (rotate 3 per post)
#YourCityName #TechHelp #LocalIT #PhoneRepair #ComputerHelp #QuickFix #TechTip #SameDayService #SupportLocal

### Trending-Sound RSS Feeds (pull 7 AM)
1. tiktok.com/@trendalert/video  
2. tokboard.com/rss  
3. TrendTok app email digest  

### Posting Schedule (auto via Metricool or Later)
- 08:00 – Problem video  
- 13:00 – Tip video  
- 19:00 – Testimonial or CTA video  

### GBP Cross-Post
- Zapier: TikTok URL → GBP “Update” with 1 geotagged photo (storefront)  
- Auto-first-comment (Metricool): “Book here → yoursite.com/30min”

---

## 4. PIXEL & LEAD CAPTURE
### TikTok Pixel Events (install via TikTok Ads → Events API)
- 3-s view → event: “3SecView”  
- 10-s view → event: “10SecView”  
- Profile click → event: “ProfileClick”  

### Daily Export → Zapier
- Filter yesterday’s viewers → CSV → Google Drive  
- Zap splits into 3 Google Customer Match audiences  

### Lead Sheet (Google Sheets)
**Columns:** Timestamp | Handle | Engagement_Level (3/10/Profile) | Phone (if DM) | Booking_Status  
**Share URL:** (see config file)

---

## 5. REMARKETING SEQUENCES
### 15-Second CTA Video Script
“Slots open this week only. I come to you—30 min, one Benjamin, speed guaranteed. Tap ‘call’ below before they’re gone.”

### Auto-DM (Zapier + TikTok API)
- **3-s viewers:** soft Q + free checklist link  
- **10-s viewers:** direct Calendly + coupon code “SPEED10” (expires 48 h)

### GBP “Call Now” Auto-Reply (via GBP Messaging)
Text: “Hi! What time today or tomorrow works best for your 30-min Tech Health Check? Reply here or book directly: calendly.com/30minTechCheck”

---

## 6. DAILY OPTIMIZATION ROUTINE (5 min)
1. Pull metrics (TikTok analytics + GBP Insights)  
2. Identify best hook (highest 10-s retention) → duplicate into 2 new variants (change word order or color)  
3. Pause lowest-retention video (< 25 %) → replace with fresh variant  
4. Check local map pack rank (BrightLocal) – if keyword “laptop repair” outside top-5, update GBP description with new keyword & city

---

## 7. FILE & TOOL CHECKLIST
- [ ] TikTok Business account verified  
- [ ] Pixel installed on profile & website  
- [ ] Metricool or Later account connected  
- [ ] Zapier plan (Starter) with TikTok + Sheets + GBP  
- [ ] Calendly event “30-min Tech Health Check” ($100, buffer 15 min, auto timezone)  
- [ ] Canva template for 1080×1920 thumbnails  
- [ ] Google Sheet shared with Zapier service account  
- [ ] Tracked phone number (CallRail or Google Voice)

---

## 8. ROLL-OUT TIMELINE
**Day 0:** Install pixel, create sheet, connect tools  
**Day 1:** Upload 3 videos, schedule 3 posts, publish GBP post  
**Day 2:** Enable auto-DM & first-comment links  
**Day 3:** Start daily optimization loop  
**Week 1 Goal:** 5 bookings @ $100 = $500 revenue  
**Week 4 Goal:** 30 bookings → $3 k, retainer upsell 20 %

---

*End of playbook—deploy and start printing appointments.*
