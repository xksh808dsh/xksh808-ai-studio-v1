
# Phase 6: Daily Optimization & Reporting  
*Deliverable: repeatable 5-minute morning routine to keep the funnel lean and growing*

---

## 1. Morning Metrics Pull (≤ 60 s)
Open the TikTok “Analytics → Content → Yesterday” export and GBP Insights email.  
Copy the following into the running Google Sheet tab “Daily KPI”:

| Metric (prev day) | Source | 3-day avg | Action flag |
|-------------------|--------|-----------|-------------|
| Impressions       | TT     | auto      | —           |
| 3-s views         | TT     | auto      | < 35 % of impressions = yellow |
| 10-s views        | TT     | auto      | < 15 % of impressions = red |
| Profile clicks    | TT     | auto      | < 1.5 % of impressions = yellow |
| Bookings          | Cal    | auto      | 0 = red     |

Conditional-format red cells → trigger “Replace” workflow below.

---

## 2. Hook Optimization (≤ 90 s)
1. Sort “Daily KPI” by 3-s-retention % (desc).  
2. Copy top headline → paste into cell “Best Hook”.  
3. Generate two variants with the simple swap rule:  
   - **Verb swap**: “Stop” → “Quit”, “Freeze”, “Skip”  
   - **Number swap**: “3 signs” → “2 signs”, “4 clues”  
   Example:  
   - Winner: “Stop paying for slow Wi-Fi”  
   - Variant A: “Quit paying for slow Wi-Fi”  
   - Variant B: “Skip paying for slow Wi-Fi”  
4. Add variants to tomorrow’s content queue (pre-scheduled 08:00 slot).

---

## 3. Content Hygiene (≤ 60 s)
Filter videos with < 25 % 3-s retention AND < 5 % 10-s retention.  
Pause (unpublish) the worst performer → slot in the new variant created above.  
Keep total active videos = 9 (3 per time slot) to avoid audience fatigue.

---

## 4. GBP Map-Pack Check (≤ 90 s)
1. Incognito search “laptop repair near me” (or primary KW).  
2. Note map rank (1-20).  
3. If rank > 5:  
   - Append one high-intent keyword to GBP description line 1:  
     “Same-day laptop & PC repair | 30-min Tech Health Check”  
   - Re-save → Google re-indexes within 24 h.  
4. Log new rank next day; revert keyword if no improvement.

---

## 5. End-of-Week Report (auto email)
Zapier → every Monday 09:00  
- Pull 7-day sums from Sheet  
- Email body:

```
Subject: 7-Sec Monday Funnel Report  
Impressions: 41 200 (↑12 %)  
3-s retention: 38 % (▲3 pts)  
Bookings: 9 (↑2)  
Top hook: “Stop paying for slow Wi-Fi”  
Next test: verb swap variants  
Action: paused 1 low-retention video, added GBP keyword “same-day”
```

---

## Tools & Links Checklist
- TikTok analytics export (daily)  
- GBP Insights email (daily)  
- Google Sheet “Daily KPI” (shared with Zapier)  
- Zapier zaps: (1) append CSV → Sheet, (2) Monday email  
- Content queue in Metricool / Later (pre-loaded with variants)

*Total desk time: 5 min. Red-cell flags guarantee continuous improvement while the funnel assets stay fresh and locally discoverable.*
