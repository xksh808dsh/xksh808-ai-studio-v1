
# Phase 3: Automate Publishing & Targeting

## 1. Local Hashtags & Trending Sounds (Daily Refresh)

### 9 Local Hashtags
- #TechHealthCheck
- #LocalTechHelp
- #FixMyPC
- #SpeedUpMyLaptop
- #VirusRemoval
- #SameDayTechFix
- #YourCityTechies (replace YourCity)
- #SmallBizTech
- #HomeOfficeRescue

### 3 Trending-Sound RSS Feeds (auto-update)
1. TikTok Creative Center RSS (Top 3 trending sounds in “Tech & Gadgets” category)
   - Feed URL: https://ads.tiktok.com/business/creativecenter/popular/music/pad/en
2. Tokboard RSS (chart toppers refreshed every 6 h)
   - Feed URL: https://tokboard.com/rss
3. TrendTok App RSS (localised trending audio)
   - Feed URL: https://trendtok.app/rss

Implementation note: use Zapier / Make.com “RSS → Google Sheets” to auto-pull top 3 sounds daily; then pick the highest-ranked sound that is <30 s and royalty-free for business use.

## 2. Auto-Post Schedule (TikTok)

Platform: TikTok (via TikTok Scheduler or Metricool)
- 08:00 local – Problem-agitation video
- 13:00 local – Quick-win tip video
- 19:00 local – Social-proof testimonial video

Upload checklist:
- 9 hashtags above pasted in caption
- Trending sound pulled from RSS feed #1
- Cover image = 1080×1920 thumbnail template (created Phase 2)
- Caption ends with “Book 30-min Tech Health Check ⬆️ link in bio”

## 3. Cross-Post to Google Business Profile “Update”

Tool: GBP API + Zapier
Trigger: TikTok video goes live
Action:
- Create GBP “Update”
- Text: same caption minus TikTok-specific hashtags
- Add geotagged photo (screenshot of video thumbnail)
- CTA button: “Call now” → phone number
- Auto-post immediately after TikTok publish

## 4. Auto-First-Comment with Booking Link

Tool: TikTok Scheduler “first comment” feature or Metricool
Text:
“👋 Need this fixed today? Grab a slot: https://calendly.com/yourhandle/30min (opens in app)”
Post delay: 30 s after video goes live

## 5. Stack & Tools Summary

- RSS aggregator → Google Sheets (trending sounds)
- TikTok Scheduler / Metricool (3× daily posts)
- Zapier (GBP cross-post)
- Calendly (booking page)
- Canva (thumbnail batch export 1080×1920)

## 6. Quick Setup Checklist

1. Connect TikTok & GBP accounts to scheduler
2. Paste 9 hashtags into “default hashtag bank”
3. Import 3 video files (Phase 2 scripts already shot)
4. Set cover = thumbnail template
5. Enable “first comment” with Calendly link
6. Create Zap: TikTok “new post” → GBP “create update”
7. Test-run one post; verify geotag & CTA button appear on GBP

Result: 3 videos/day auto-published, cross-posted to local GBP, trending sound refreshed daily, booking link auto-dropped in first comment—zero manual work after initial setup.
