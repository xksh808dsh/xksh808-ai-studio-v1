# STOP! Did You Have a 5-Star Experience?

## Help Us Out! It Only Takes 10 Seconds.

We work hard to make your day great. If we succeeded, please show us some love!

**Scan the QR Code Below to Leave a 5-Star Review on Google.**

---

## [PLACEHOLDER FOR CUSTOMER'S QR CODE]

**(Instructions for Client: Insert your Google Review Link QR Code here. We recommend a 4x4 inch size for maximum scannability.)**

---

### Thank You for Supporting Local Business!

*   **Placement Suggestion:** Near the register, on the exit door, or on a table tent.
*   **Design Note:** This is a clean, high-contrast template designed for easy printing and maximum customer attention. The final design should be printed on high-quality card stock.
