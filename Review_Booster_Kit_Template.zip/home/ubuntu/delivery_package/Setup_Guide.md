# 1-Page Setup Guide: 24-Hour 5-Star Review Booster Kit

This kit is designed for maximum simplicity and speed. Follow these three steps to start generating 5-star reviews today.

## Step 1: Generate Your QR Code
1.  **Find Your Review Link:** Go to Google and search for your business. Click the "Write a review" button. Copy the URL that appears in your browser's address bar. This is your direct review link.
2.  **Generate the Code:** Use a free online QR code generator (e.g., QR Code Monkey) and paste your direct review link. Download the QR code image as a high-resolution PNG or SVG.
3.  **Insert into Poster:** Open the `Review_QR_Poster_Template.md` (or the final PDF/PNG we provide) and insert your newly generated QR code image into the designated placeholder.

## Step 2: Print and Place the Poster
1.  **Print:** Print the final poster design on high-quality, thick paper (card stock is best).
2.  **Placement:** Place the poster in a high-traffic, high-dwell-time area:
    *   **Near the Point of Sale (POS):** The most effective spot.
    *   **On the Exit Door:** A final reminder.
    *   **On Table Tents:** For cafes or restaurants.

## Step 3: Train Your Staff (The Secret Weapon)
The poster is only 50% of the solution. The other 50% is the staff script.
1.  **Distribute:** Give every staff member the `Staff_Script.txt` file.
2.  **Drill:** Have them practice the 3-line script until it feels natural.
3.  **Incentivize:** Consider a small daily or weekly bonus for the staff member who gets the most customers to scan the code.

**Goal:** Make asking for the review a mandatory, non-negotiable part of the checkout process.

**You are now ready to boost your 5-star reviews!**
